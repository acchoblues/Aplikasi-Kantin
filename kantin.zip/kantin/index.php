<html>
<head>
<title>Scan Barcode Makan | www.niqoweb.com</title>
<meta name="author" content="Hakko Bio Richard"/>

<link rel="stylesheet" type="text/css" href="datatables/dataTables.bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css"/>
<script src="dist/sweetalert-dev.js"></script>
    <link rel="stylesheet" href="dist/sweetalert.css">
</head>
<body>
<center><img src="hakkoblogs.jpg" style="margin-top: 30px; border-radius: 100px; border: 4px solid #888;" height="200" width="200" /></center>
<h1><center>Scan Barcode Anda Untuk Makan</center></h1>

<div class="col-lg-12" style="margin-top: 10px;">
<?php
        /**    $kd = $_GET['id'];
			$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE user_id='$kd'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: admin.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			} **/
            
            include "conn.php";
			if(isset($_POST['kode'])){
			  $kode = $_POST['kode'];
              $tanggal = date("Y-m-d");
              $jam = date("H:i:s");
			 $sql = mysqli_query($koneksi, "SELECT * FROM makan WHERE nik='$kode' and tanggal='$tanggal'");
			if(mysqli_num_rows($sql) == 0){
			    //$row = mysqli_fetch_assoc($sql);
				$update = mysqli_query($koneksi, "INSERT INTO makan (nik,tanggal,jam) VALUES
            ('$kode','$tanggal','$jam')") or die(mysqli_error());
				if($update){
					echo '<script>sweetAlert({
	                                                   title: "Berhasil!", 
                                                        text: "Silahkan Makan!", 
                                                        type: "success"
                                                        });</script>';
                }else{
					echo '<script>sweetAlert({
	                                                   title: "Gagal!", 
                                                        text: "Data Gagal di input, silahakan coba lagi!", 
                                                        type: "error"
                                                        });</script>';
                    }
			}else{
				echo '<script>sweetAlert({
	                                                   title: "Anda sudah makan hari ini!", 
                                                        text: "Tidak boleh makan 2 kali!", 
                                                        type: "error"
                                                        });</script>';
                    
             	}
			
   }
			
			?>
            
             <form method="POST" name="update" action="index.php">
<center><input name="kode" style="width:500px; height:100px; font-size: 40px;" class="form-control" placeholder="Scan QR Code" onchange="this.form.submit();" autofocus="on" autocomplete="off"/></center>
</form>
<!--<center><a href="hadir.php" class="btn btn-lg btn-primary">List Data</a></center>-->
</div>
<div class="col-lg-12" style="margin-top: 50px; margin-bottom: 40px;">
 <?php 
 $cari=date("Y-m-d");
 $tampil=mysqli_query($koneksi, "select * from makan where tanggal='$cari'");
                        $total=mysqli_num_rows($tampil);
                        ?>
 <div class="col-lg-12">
 <div class="panel panel-success">
 <div class="panel-heading"><h1 style="text-align: center;"><b>Total Makan Hari Ini</b></h1></div>
  <div class="panel-body">
    <p style="font-size: 100; text-align: center;"><b><?php echo $total; ?></b></p>
  </div>
 </div>
 </div>
 <!--
 <div class="col-lg-4">
 <div class="panel panel-primary">
 <div class="panel-heading"><h2>Total Makan Kemarin</h2></div>
  <div class="panel-body">
    
  </div>
 </div>
 </div>
 
 <div class="col-lg-4">
 <div class="panel panel-primary">
 <div class="panel-heading"><h2>Akumulasi Makan Perbulan</h2></div>
  <div class="panel-body">
    
  </div>-->
 </div>
 </div>
  </div>
  
  
  <!-- Javascript Libs -->
            <script type="text/javascript" src="js/jquery-2.1.1.js"></script>
            <script type="text/javascript" src="datatables/jquery.dataTables.min.js"></script>
            <script type="text/javascript" src="datatables/dataTables.bootstrap.min.js"></script>
            <script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
            
            
            <script>
        $(document).ready(function() {
				var dataTable = $('#lookup').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						url :"ajax-grid-data.php", // json datasource
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".lookup-error").html("");
							$("#lookup").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
							$("#lookup_processing").css("display","none");
							
						}
					}
				} );
			} );
        </script>
</body>
</html>