<html>
<head>
<title>Registrasi Meet Up Komitkabe| www.niqoweb.com</title>
<meta name="author" content="Hakko Bio Richard"/>

<link rel="stylesheet" type="text/css" href="datatables/dataTables.bootstrap.css"/>
<link rel="stylesheet" type="text/css" href="dist/css/bootstrap.min.css"/>
<script src="dist/sweetalert-dev.js"></script>
    <link rel="stylesheet" href="dist/sweetalert.css">
</head>
<body>
<h3><center>Scan Barcode Anda Untuk Makan</center></h3>

<div class="col-lg-12" style="margin-top: 40px;">
<?php
        /**    $kd = $_GET['id'];
			$sql = mysqli_query($koneksi, "SELECT * FROM user WHERE user_id='$kd'");
			if(mysqli_num_rows($sql) == 0){
				header("Location: admin.php");
			}else{
				$row = mysqli_fetch_assoc($sql);
			} **/
            
            include "conn.php";
			if(isset($_POST['kode'])){
			  $kode = $_POST['kode'];
              $tanggal = date("Y-m-d");
              $jam = date("H:i:s");
			 $sql = mysqli_query($koneksi, "SELECT * FROM kantin WHERE nik='$kode' and tanggal='$tanggal'");
			if(mysqli_num_rows($sql) == 0){
			    //$row = mysqli_fetch_assoc($sql);
				$update = mysqli_query($koneksi, "INSERT INTO kantin (nik,tanggal,jam) VALUES
            ('$kode','$tanggal','$jam')") or die(mysqli_error());
				if($update){
					echo '<script>sweetAlert({
	                                                   title: "Berhasil!", 
                                                        text: "Silahkan Makan!", 
                                                        type: "success"
                                                        });</script>';
                }else{
					echo '<script>sweetAlert({
	                                                   title: "Gagal!", 
                                                        text: "Data Gagal di input, silahakan coba lagi!", 
                                                        type: "error"
                                                        });</script>';
                    }
			}else{
				echo '<script>sweetAlert({
	                                                   title: "Anda sudah makan hari ini!", 
                                                        text: "Tidak boleh makan 2 kali!", 
                                                        type: "error"
                                                        });</script>';
                    
             	}
			
   }
			
			?>
            
           <!--  <form method="POST" name="update" action="hadir.php">
<center><input name="kode" class="form-control" placeholder="Scan QR Code" onchange="this.form.submit();" autofocus="on" autocomplete="off"/></center>
</form> -->
</div>
<div class="col-lg-12" style="margin-top: 20px; margin-bottom: 40px;">
 
   <table id="lookup" class="table table-bordered table-hover">  
	<thead bgcolor="eeeeee" align="center">
      <tr>
	  
       <th>Id</th>
	   <th>Nik</th>
        <th>Tanggal</th>
         <th>Jam</th>
	   
	  
      </tr>
    </thead>
    <tbody>
	 
					 
    </tbody>
  </table>
  <center><a href="index.php" class="btn btn-sm btn-primary">Kembali</a></center>
  </div>
  
  
  <!-- Javascript Libs -->
            <script type="text/javascript" src="js/jquery-2.1.1.js"></script>
            <script type="text/javascript" src="datatables/jquery.dataTables.min.js"></script>
            <script type="text/javascript" src="datatables/dataTables.bootstrap.min.js"></script>
            <script type="text/javascript" src="dist/js/bootstrap.min.js"></script>
            
            
            <script>
        $(document).ready(function() {
				var dataTable = $('#lookup').DataTable( {
					"processing": true,
					"serverSide": true,
					"ajax":{
						url :"ajax-grid-data.php", // json datasource
						type: "post",  // method  , by default get
						error: function(){  // error handling
							$(".lookup-error").html("");
							$("#lookup").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
							$("#lookup_processing").css("display","none");
							
						}
					}
				} );
			} );
        </script>
</body>
</html>